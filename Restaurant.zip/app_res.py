import pathlib
from check import setting_res
from proje1_ras import *





print("""

            salam be ghazakhori ma khosh amadid

""")

# while True:
    # temp = input("restoran ma oomadi ya na?(y/n): ")
    # if temp == "n":
    #     print("Bia restoran ma !!")
    #     try:
    #         username = input("esm chi mikhay?")
    #         password = input("ye ramz bezan")
    #         print(username, password)

    #     except:
    #         print("aziz jan ramz bayad monhaser be fard bashe")
    #         break
    #     # ali = basefood()
    #     a = basefood('morgh','big','big')
    #     print(a.infofood())

a =basefood('berenj' , 'irani','adult')
a.change_food()









