from proje1_ras import *
import pickle
import setting_res




# admin_object = Admin("ali", "1234")
# admin_object = Admin("ali", "1234")

# member_object = Member("asghar", "1234")


# admin_object.save()
# member_object.save()

# def loadall(filename):
#     with open(filename, "rb") as f:
#         while True:
#             try:
#                 yield pickle.load(f)
#             except EOFError:
#                 break


# items = loadall(setting_res.USER_DATA_PATH / "admins.db")


# for item in items:
#     print(item.username)
#     print(item.password)

# dbfile = open(setting_res.USER_DATA_PATH / "members.db", 'rb')     
# db = pickle.load(dbfile)    

# for elm in db:
#     print(elm.username)

# dbfile.close()

# for elm in Member.query.loadall():
#     print(elm.username)



# a =basefood('berenj' ,'irani' , 'big')




# print(a.infofood)







